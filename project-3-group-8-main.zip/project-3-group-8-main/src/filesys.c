#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <inttypes.h>
#include <fcntl.h>
#include <sys/types.h>  // Include this for pid_t

typedef struct openFile {
    uint32_t offsetInParent;
    uint32_t offsetInDataRegion;
    uint32_t offsetInFile;
    uint32_t fileClusNumber;
    uint32_t fileSize;
    char * fileName;
    char * filePath;
    char fileMode[2];
} OpenFile;

struct {
    uint16_t BPB_BytsPerSec;
    uint8_t BPB_SecPerClus;
    uint16_t BPB_RsvdSecCnt;
    uint8_t BPB_NumFATs;
    uint32_t BPB_FATSz32;
    uint32_t BPB_RootClus;

    int imgSize;
    uint32_t dataRegionAddress;
    uint32_t numOfClusInRegion;
    uint32_t numOfEntriesPerFAT;
    uint32_t currentOffset;
    uint32_t currentClusNumber;
    uint32_t maxClusNumber;
    uint32_t minClusNumber;
    int numOfOpenFiles;
    OpenFile openedFiles[10] ;
} bpb_info;

typedef struct {
    char ** items;
    size_t size;
} tokenlist;

typedef struct __attribute__((packed)) directory_entry {
    char DIR_Name[11];
    uint8_t DIR_Attr;
    char padding_1[8]; // DIR_NTRes, DIR_CrtTimeTenth, DIR_CrtTime, DIR_CrtDate,
                       // DIR_LstAccDate. Since these fields are not used in
                       // Project 3, just define as a placeholder.
    uint16_t DIR_FstClusHI;
    char padding_2[4]; // DIR_WrtTime, DIR_WrtDate
    uint16_t DIR_FstClusLO;
    uint32_t DIR_FileSize;
} dentry_t;

char *get_input(void) {
	char *buffer = NULL;
	int bufsize = 0;
	char line[5];
	while (fgets(line, 5, stdin) != NULL)
	{
		int addby = 0;
		char *newln = strchr(line, '\n');
		if (newln != NULL)
			addby = newln - line;
		else
			addby = 5 - 1;
		buffer = (char *)realloc(buffer, bufsize + addby);
		memcpy(&buffer[bufsize], line, addby);
		bufsize += addby;
		if (newln != NULL)
			break;
	}
	buffer = (char *)realloc(buffer, bufsize + 1);
	buffer[bufsize] = 0;
	return buffer;
}

tokenlist *new_tokenlist(void) {
	tokenlist *tokens = (tokenlist *)malloc(sizeof(tokenlist));
	tokens->size = 0;
	tokens->items = (char **)malloc(sizeof(char *));
	tokens->items[0] = NULL; /* make NULL terminated */
	return tokens;
}

void add_token(tokenlist *tokens, char *item) {
	int i = tokens->size;

	tokens->items = (char **)realloc(tokens->items, (i + 2) * sizeof(char *));
	tokens->items[i] = (char *)malloc(strlen(item) + 1);
	tokens->items[i + 1] = NULL;
	strcpy(tokens->items[i], item);

	tokens->size += 1;
}

tokenlist *get_tokens(char *input) {
	char *buf = (char *)malloc(strlen(input) + 1);
	strcpy(buf, input);
	tokenlist *tokens = new_tokenlist();
	char *tok = strtok(buf, " ");
	while (tok != NULL)
	{
            add_token(tokens, tok);
            tok = strtok(NULL, " ");
	}
	free(buf);
	return tokens;
}

void free_tokens(tokenlist *tokens) {
	for (int i = 0; i < tokens->size; i++)
		free(tokens->items[i]);
	free(tokens->items);
	free(tokens);
}

void remove_spaces(char * fileName) {
    int fileNameLength = strlen(fileName) - 1;

    while (fileName[fileNameLength - 1] == ' ' && fileNameLength > 0) {
        if (fileName[fileNameLength] != 0x20) {
            fileName[fileNameLength] = '\0';
        }

        fileName[fileNameLength - 1] = '\0';
        fileNameLength--;
    }
}

void print_info()
{
    printf("Bytes Per Sector: %u\n", bpb_info.BPB_BytsPerSec);
    printf("Sectors Per Cluster: %u\n", bpb_info.BPB_SecPerClus);
    printf("Root Cluster: %u\n", bpb_info.BPB_RootClus);
    printf("Total clusters in Data Region: %u\n", bpb_info.numOfClusInRegion);
    printf("# of entries in one FAT: %u\n", bpb_info.numOfEntriesPerFAT);
    printf("Size of Image (bytes): %d\n", bpb_info.imgSize);
}

dentry_t * read_dir_entry(FILE * fat32_fp, uint32_t offset) {
    dentry_t * dentry = (dentry_t*)malloc(sizeof(dentry_t));
    fseek(fat32_fp, offset, SEEK_SET);
    fread((void*)dentry, sizeof(dentry_t), 1, fat32_fp);

    return dentry;
}

uint32_t clusNumToFatOffset(uint32_t clusNumber) {
    uint32_t fatOffset = 0x4000;
    return fatOffset + clusNumber * 4;
}

int check_file_open(char * targetFile) {
    for (int i = 0; i < bpb_info.numOfOpenFiles; i++) {
        if (strcmp(bpb_info.openedFiles[i].fileName, targetFile) == 0) {
            return i;
        }
    }

    return -1;
}

void ls_command(FILE * fat32_fp) {
    uint32_t tempOffset = bpb_info.currentOffset;
    uint32_t tempClusNumber = bpb_info.currentClusNumber;
    uint32_t nextClusNumber = 0;

    // while loop for cluster chain (starting at current cluster)
    while (tempClusNumber >= bpb_info.minClusNumber && tempClusNumber <= bpb_info.maxClusNumber)
    {
        // finds the FAT entry of current cluster to find next cluster if there is one
        uint32_t fatOffset = clusNumToFatOffset(tempClusNumber);
        fseek(fat32_fp, fatOffset, SEEK_SET);
        fread(&nextClusNumber, sizeof(uint32_t), 1, fat32_fp);

        // for loop that iterates through all directory entries within cluster (32 * 16 bytes = 512)
        for (int i = 0; i < 16; i++) {
            dentry_t *dentry = read_dir_entry(fat32_fp, tempOffset);
            tempOffset += 32; // increments to next directory entry

            if (dentry->DIR_Attr != 0x0F && strlen(dentry->DIR_Name) != 0) {
                if (dentry->DIR_Attr == 0x10) {
                    printf("\033[0;94m"); // changes print color to light blue for directories
                }

                char * dirName = dentry->DIR_Name;
                remove_spaces(dirName);
                printf("%s\n", dirName);
                printf("\033[0m"); // resets print color back to white
            }

            free(dentry);
        }

        // updates temp cluster number to find next set of data in cluster chain
        tempClusNumber = nextClusNumber;

        // updates temporary offset so data can be printed from new offset
        tempOffset = bpb_info.dataRegionAddress + (tempClusNumber - bpb_info.BPB_RootClus) * bpb_info.BPB_BytsPerSec;
    }
}

int cd_command(FILE * fat32_fp, char * targetDir) {
    uint32_t tempOffset = bpb_info.currentOffset;
    uint32_t tempClusNumber = bpb_info.currentClusNumber;
    uint32_t nextClusNumber = 0;

    // while loop for cluster chain (starting at current cluster)
    while (tempClusNumber >= bpb_info.minClusNumber && tempClusNumber <= bpb_info.maxClusNumber)
    {
        // finds the FAT entry of current cluster to find next cluster if there is one
        uint32_t fatOffset = clusNumToFatOffset(tempClusNumber);
        fseek(fat32_fp, fatOffset, SEEK_SET);
        fread(&nextClusNumber, sizeof(uint32_t), 1, fat32_fp);

        // for loop that iterates through all directory entries within cluster (32 * 16 bytes = 512)
        for (int i = 0; i < 16; i++) {
            dentry_t *dentry = read_dir_entry(fat32_fp, tempOffset);
            tempOffset += 32; // increments to next directory entry

            if (dentry->DIR_Attr == 0x10) {
                char dirName[strlen(dentry->DIR_Name)];
                strcpy(dirName, dentry->DIR_Name);
                remove_spaces(dirName);

                if (strcmp(targetDir, dirName) == 0) {
                    uint32_t dirClusNumber = (dentry->DIR_FstClusHI << 16) | dentry->DIR_FstClusLO;

                    if (dirClusNumber == 0) {
                        dirClusNumber = 2;
                    }

                    // updates current clus number the user is in
                    bpb_info.currentClusNumber = dirClusNumber;

                    // updates current offset the user is in
                    uint32_t newOffset = bpb_info.dataRegionAddress + (dirClusNumber - bpb_info.BPB_RootClus) * bpb_info.BPB_BytsPerSec;
                    bpb_info.currentOffset = newOffset;

                    free(dentry);

                    return 1;
                }
            }

            free(dentry);
        }

        // updates temp cluster number to find next set of data in cluster chain
        tempClusNumber = nextClusNumber;

        // updates temporary offset so directories can be searched in next cluster
        tempOffset = bpb_info.dataRegionAddress + (tempClusNumber - bpb_info.BPB_RootClus) * bpb_info.BPB_BytsPerSec;
    }

    return -1;
}

int open_command(FILE * fat32_fp, char * targetFile, char * mode) {
    uint32_t tempOffset = bpb_info.currentOffset;
    uint32_t tempClusNumber = bpb_info.currentClusNumber;
    uint32_t nextClusNumber = 0;

    // while loop for cluster chain (starting at current cluster)
    while (tempClusNumber >= bpb_info.minClusNumber && tempClusNumber <= bpb_info.maxClusNumber)
    {
        // finds the FAT entry of current cluster to find next cluster if there is one
        uint32_t fatOffset = clusNumToFatOffset(tempClusNumber);
        fseek(fat32_fp, fatOffset, SEEK_SET);
        fread(&nextClusNumber, sizeof(uint32_t), 1, fat32_fp);

        // for loop that iterates through all directory entries within cluster (32 * 16 bytes = 512)
        for (int i = 0; i < 16; i++) {
            dentry_t *dentry = read_dir_entry(fat32_fp, tempOffset);
            tempOffset += 32; // increments to next directory entry

            char dirName[strlen(dentry->DIR_Name)];
            strcpy(dirName, dentry->DIR_Name);
            remove_spaces(dirName);

            if (strcmp(targetFile, dirName) == 0) {
                if (check_file_open(targetFile) == -1) {
                    if (bpb_info.numOfOpenFiles < 10) {
                        bpb_info.openedFiles[bpb_info.numOfOpenFiles].offsetInParent = tempOffset;
                        bpb_info.openedFiles[bpb_info.numOfOpenFiles].offsetInFile = 0;
                        bpb_info.openedFiles[bpb_info.numOfOpenFiles].fileClusNumber = (dentry->DIR_FstClusHI << 16) | dentry->DIR_FstClusLO;
                        bpb_info.openedFiles[bpb_info.numOfOpenFiles].offsetInDataRegion = bpb_info.dataRegionAddress
                                                                                           + (bpb_info.openedFiles[bpb_info.numOfOpenFiles].fileClusNumber - bpb_info.BPB_RootClus)
                                                                                           * bpb_info.BPB_BytsPerSec;
                        bpb_info.openedFiles[bpb_info.numOfOpenFiles].fileSize = dentry->DIR_FileSize;
                        bpb_info.openedFiles[bpb_info.numOfOpenFiles].fileMode[0] = mode[1];

                        if (strlen(mode) == 3) {
                            bpb_info.openedFiles[bpb_info.numOfOpenFiles].fileMode[1] = mode[2];
                        }

                        free(dentry);

                        return 1;
                    } else {
                        printf("Max open file limit reached (10 files).\n");
                        return -1;
                    }
                } else {
                    printf("File is already open.\n");
                    return -1;
                }
            }

            free(dentry);
        }

        // updates temp cluster number to find next set of data in cluster chain
        tempClusNumber = nextClusNumber;

        // updates temporary offset so data can be printed from new offset
        tempOffset = bpb_info.dataRegionAddress + (tempClusNumber - bpb_info.BPB_RootClus) * bpb_info.BPB_BytsPerSec;
    }

    return 0;
}

int close_command(FILE * fat32_fp, char * targetFile, int openFileIndex) {
    uint32_t tempOffset = bpb_info.currentOffset;
    uint32_t tempClusNumber = bpb_info.currentClusNumber;
    uint32_t nextClusNumber = 0;

    // while loop for cluster chain (starting at current cluster)
    while (tempClusNumber >= bpb_info.minClusNumber && tempClusNumber <= bpb_info.maxClusNumber)
    {
        // finds the FAT entry of current cluster to find next cluster if there is one
        uint32_t fatOffset = clusNumToFatOffset(tempClusNumber);
        fseek(fat32_fp, fatOffset, SEEK_SET);
        fread(&nextClusNumber, sizeof(uint32_t), 1, fat32_fp);

        // for loop that iterates through all directory entries within cluster (32 * 16 bytes = 512)
        for (int i = 0; i < 16; i++) {
            dentry_t *dentry = read_dir_entry(fat32_fp, tempOffset);
            tempOffset += 32; // increments to next directory entry

            char dirName[strlen(dentry->DIR_Name)];
            strcpy(dirName, dentry->DIR_Name);
            remove_spaces(dirName);

            if (strcmp(targetFile, dirName) == 0) {
                for (int i = openFileIndex; i < bpb_info.numOfOpenFiles; i++) {
                    bpb_info.openedFiles[i] = bpb_info.openedFiles[i + 1];
                }

                bpb_info.numOfOpenFiles--;

                free(dentry);

                return 1;
            }

            free(dentry);
        }

        // updates temp cluster number to find next set of data in cluster chain
        tempClusNumber = nextClusNumber;

        // updates temporary offset so data can be printed from new offset
        tempOffset = bpb_info.dataRegionAddress + (tempClusNumber - bpb_info.BPB_RootClus) * bpb_info.BPB_BytsPerSec;
    }

    return -1;
}

int lseek_command(FILE * fat32_fp, char * targetFile, int openFileOffset, int openFileIndex) {
    uint32_t tempOffset = bpb_info.currentOffset;
    uint32_t tempClusNumber = bpb_info.currentClusNumber;
    uint32_t nextClusNumber = 0;

    // while loop for cluster chain (starting at current cluster)
    while (tempClusNumber >= bpb_info.minClusNumber && tempClusNumber <= bpb_info.maxClusNumber)
    {
        // finds the FAT entry of current cluster to find next cluster if there is one
        uint32_t fatOffset = clusNumToFatOffset(tempClusNumber);
        fseek(fat32_fp, fatOffset, SEEK_SET);
        fread(&nextClusNumber, sizeof(uint32_t), 1, fat32_fp);

        // for loop that iterates through all directory entries within cluster (32 * 16 bytes = 512)
        for (int i = 0; i < 16; i++) {
            dentry_t *dentry = read_dir_entry(fat32_fp, tempOffset);
            tempOffset += 32; // increments to next directory entry

            char dirName[strlen(dentry->DIR_Name)];
            strcpy(dirName, dentry->DIR_Name);
            remove_spaces(dirName);

            if (strcmp(targetFile, dirName) == 0) {
                if (openFileOffset <= dentry->DIR_FileSize) {
                    bpb_info.openedFiles[openFileIndex].offsetInFile = openFileOffset;

                    free(dentry);

                    return 1;
                } else {
                    free(dentry);

                    return -2;
                }
            }

            free(dentry);
        }

        // updates temp cluster number to find next set of data in cluster chain
        tempClusNumber = nextClusNumber;

        // updates temporary offset so data can be printed from new offset
        tempOffset = bpb_info.dataRegionAddress + (tempClusNumber - bpb_info.BPB_RootClus) * bpb_info.BPB_BytsPerSec;
    }

    return -1;
}

int read_command(FILE * fat32_fp, OpenFile openFile, int readSize) {
    uint32_t tempOffset = openFile.offsetInDataRegion + openFile.offsetInFile;
    uint32_t tempClusNumber = openFile.fileClusNumber;
    uint32_t nextClusNumber = 0;
    int bytesLeftToRead = 0;
    int firstClusFlag = 1;

    if ((openFile.offsetInFile + readSize) > openFile.fileSize) {
        bytesLeftToRead = openFile.fileSize - openFile.offsetInFile;
    } else {
        bytesLeftToRead = readSize;
    }

    // while loop for cluster chain (starting at current cluster)
    while (tempClusNumber >= bpb_info.minClusNumber && tempClusNumber <= bpb_info.maxClusNumber)
    {
        // finds the FAT entry of current cluster to find next cluster if there is one
        uint32_t fatOffset = clusNumToFatOffset(tempClusNumber);
        fseek(fat32_fp, fatOffset, SEEK_SET);
        fread(&nextClusNumber, sizeof(uint32_t), 1, fat32_fp);

        // reads all bytes at current cluser (512 bytes)
        if (firstClusFlag == 1 && ((openFile.offsetInFile % 512) + bytesLeftToRead) > 512) {
            char buffer[512 - (openFile.offsetInFile % 512)];
            buffer[512 - (openFile.offsetInFile % 512)] = '\0';

            fseek(fat32_fp, tempOffset, SEEK_SET);
            fread(buffer, 512 - (openFile.offsetInFile % 512), 1, fat32_fp);
            bytesLeftToRead -= (512 - (openFile.offsetInFile % 512));

            firstClusFlag = 0;

            printf("%s", buffer);
        } else {
            if (bytesLeftToRead > 512) {
                char buffer[512];
                buffer[512] = '\0';

                fseek(fat32_fp, tempOffset, SEEK_SET);
                fread(buffer, 512, 1, fat32_fp);
                bytesLeftToRead -= 512;

                printf("%s", buffer);
            } else {
                char buffer[bytesLeftToRead];
                buffer[bytesLeftToRead] = '\0';

                fseek(fat32_fp, tempOffset, SEEK_SET);
                fread(buffer, bytesLeftToRead, 1, fat32_fp);
                bytesLeftToRead = 0;

                printf("%s", buffer);
            }
        }

        // updates temp cluster number to find next set of data in cluster chain
        tempClusNumber = nextClusNumber;

        // updates temporary offset so data can be printed from new offset
        tempOffset = bpb_info.dataRegionAddress + (tempClusNumber - bpb_info.BPB_RootClus) * bpb_info.BPB_BytsPerSec;
    }

    printf("\n");

    if ((openFile.offsetInFile + readSize) > openFile.fileSize) {
        return openFile.fileSize - openFile.offsetInFile;
    } else {
        return readSize;
    }
}

uint32_t allocate_cluster(FILE * fat32_fp) {
    uint32_t tempClusNumber = bpb_info.minClusNumber;
    uint32_t nextClusNumber = 0;
    uint32_t newClusNumber = 0;

    while (tempClusNumber <= bpb_info.maxClusNumber) {
        uint32_t offset = clusNumToFatOffset(tempClusNumber);
        fseek(fat32_fp, offset, SEEK_SET);
        fread(&nextClusNumber, sizeof(uint32_t), 1, fat32_fp);

        if (nextClusNumber == 0) {
            newClusNumber = tempClusNumber;
            break;
        }

        tempClusNumber++;
    }

    uint32_t newOffset = clusNumToFatOffset(newClusNumber);
    fseek(fat32_fp, newOffset, SEEK_SET);
    uint32_t endOfFileMarker = 0xFFFFFFFF;
    fwrite(&endOfFileMarker, sizeof(uint32_t), 1, fat32_fp);

    return newClusNumber;
}

uint32_t extend_cluster_chain(FILE * fat32_fp, uint32_t targetClusNumber) {
    uint32_t newClusNumber = allocate_cluster(fat32_fp);

    uint32_t currentOffset = clusNumToFatOffset(targetClusNumber);
    fseek(fat32_fp, currentOffset, SEEK_SET);
    fwrite(&newClusNumber, sizeof(uint32_t), 1, fat32_fp);

    return newClusNumber;
}

int find_end_of_cluster_chain(FILE * fat32_fp, uint32_t startingClusNumber) {
    uint32_t tempClusNumber = startingClusNumber;
    uint32_t nextClusNumber = 0;
    uint32_t lastClusNumber = 0;

    // while loop for cluster chain (starting at current cluster)
    while (tempClusNumber >= bpb_info.minClusNumber && tempClusNumber <= bpb_info.maxClusNumber)
    {
        // finds the FAT entry of current cluster to find next cluster if there is one
        uint32_t fatOffset = clusNumToFatOffset(tempClusNumber);
        fseek(fat32_fp, fatOffset, SEEK_SET);
        fread(&nextClusNumber, sizeof(uint32_t), 1, fat32_fp);

        lastClusNumber = tempClusNumber;

        // updates temp cluster number to find next set of data in cluster chain
        tempClusNumber = nextClusNumber;
    }

    return lastClusNumber;
}

void mkdir_command(FILE * fat32_fp, char * newDir) {
    uint32_t tempOffset = bpb_info.currentOffset;
    uint32_t tempClusNumber = bpb_info.currentClusNumber;
    uint32_t nextClusNumber = 0;
    uint32_t lastClusNumber = 0;

    // while loop for cluster chain (starting at current cluster)
    while (tempClusNumber >= bpb_info.minClusNumber && tempClusNumber <= bpb_info.maxClusNumber)
    {
        // finds the FAT entry of current cluster to find next cluster if there is one
        uint32_t fatOffset = clusNumToFatOffset(tempClusNumber);
        fseek(fat32_fp, fatOffset, SEEK_SET);
        fread(&nextClusNumber, sizeof(uint32_t), 1, fat32_fp);

        // reads all bytes at current cluser (512 bytes)
        for (int i = 0; i < 16; i++) {
            dentry_t *dentry = read_dir_entry(fat32_fp, tempOffset);
            tempOffset += 32;

            char * dirName = dentry->DIR_Name;
            remove_spaces(dirName);

            if (strcmp(newDir, dirName) == 0) {
                printf("A directory/file with the name '%s' already exists.\n", newDir);
                free(dentry);

                return;
            } else if (dentry->DIR_Name[0] == 0x00 || dentry->DIR_Name[0] == 0xE5) {
                // if empty entry is found, then create new directory with accompanying . and .. directories
                dentry_t newDentry, newDentryDot, newDentryDotDot;

                uint32_t newDirClusNumber = allocate_cluster(fat32_fp);

                strcpy(newDentry.DIR_Name, newDir);
                newDentry.DIR_Attr = 0x10;
                newDentry.DIR_FstClusHI = (newDirClusNumber >> 16) & 0xFFFF;
                newDentry.DIR_FstClusLO = newDirClusNumber & 0xFFFF;
                newDentry.DIR_FileSize = 0;

                fseek(fat32_fp, tempOffset - 32, SEEK_SET);
                fwrite(&newDentry, sizeof(dentry_t), 1, fat32_fp);

                uint32_t newOffset = bpb_info.dataRegionAddress + (newDirClusNumber - bpb_info.BPB_RootClus) * bpb_info.BPB_BytsPerSec;
                fseek(fat32_fp, newOffset, SEEK_SET);

                strcpy(newDentryDot.DIR_Name, ".");
                newDentryDot.DIR_Attr = 0x10;
                newDentryDot.DIR_FstClusHI = (newDirClusNumber >> 16) & 0xFFFF;
                newDentryDot.DIR_FstClusLO = newDirClusNumber & 0xFFFF;
                newDentryDot.DIR_FileSize = 0;

                fwrite(&newDentryDot, sizeof(dentry_t), 1, fat32_fp);

                strcpy(newDentryDotDot.DIR_Name, "..");
                newDentryDotDot.DIR_Attr = 0x10;
                newDentryDotDot.DIR_FstClusHI = (bpb_info.currentClusNumber >> 16) & 0xFFFF;
                newDentryDotDot.DIR_FstClusLO = bpb_info.currentClusNumber & 0xFFFF;
                newDentryDotDot.DIR_FileSize = 0;

                fwrite(&newDentryDotDot, sizeof(dentry_t), 1, fat32_fp);

                free(dentry);

                return;
            }

            free(dentry);
        }

        // keeps track of last cluster in case cluster limit is reached
        lastClusNumber = tempClusNumber;

        // updates temp cluster number to find next set of data in cluster chain
        tempClusNumber = nextClusNumber;

        // updates temporary offset so data can be printed from new offset
        tempOffset = bpb_info.dataRegionAddress + (tempClusNumber - bpb_info.BPB_RootClus) * bpb_info.BPB_BytsPerSec;
    }

    // if cluster chain has no space, allocate space for a new cluster in chain and then add new directories
    uint32_t extendedDirClusNumber = extend_cluster_chain(fat32_fp, lastClusNumber);
    uint32_t newOffset = bpb_info.dataRegionAddress + (extendedDirClusNumber - bpb_info.BPB_RootClus) * bpb_info.BPB_BytsPerSec;
    dentry_t newDentry, newDentryDot, newDentryDotDot;
    uint32_t newDirClusNumber = allocate_cluster(fat32_fp);

    strcpy(newDentry.DIR_Name, newDir);
    newDentry.DIR_Attr = 0x10;
    newDentry.DIR_FstClusHI = (newDirClusNumber >> 16) & 0xFFFF;
    newDentry.DIR_FstClusLO = newDirClusNumber & 0xFFFF;
    newDentry.DIR_FileSize = 0;

    fseek(fat32_fp, newOffset, SEEK_SET);
    fwrite(&newDentry, sizeof(dentry_t), 1, fat32_fp);

    newOffset = bpb_info.dataRegionAddress + (newDirClusNumber - bpb_info.BPB_RootClus) * bpb_info.BPB_BytsPerSec;
    fseek(fat32_fp, newOffset, SEEK_SET);

    strcpy(newDentryDot.DIR_Name, ".");
    newDentryDot.DIR_Attr = 0x10;
    newDentryDot.DIR_FstClusHI = (newDirClusNumber >> 16) & 0xFFFF;
    newDentryDot.DIR_FstClusLO = newDirClusNumber & 0xFFFF;
    newDentryDot.DIR_FileSize = 0;

    fwrite(&newDentryDot, sizeof(dentry_t), 1, fat32_fp);

    strcpy(newDentryDotDot.DIR_Name, "..");
    newDentryDotDot.DIR_Attr = 0x10;
    newDentryDotDot.DIR_FstClusHI = (bpb_info.currentClusNumber >> 16) & 0xFFFF;
    newDentryDotDot.DIR_FstClusLO = bpb_info.currentClusNumber & 0xFFFF;
    newDentryDotDot.DIR_FileSize = 0; // might have to change this to account for file size of parent directory
    fwrite(&newDentryDotDot, sizeof(dentry_t), 1, fat32_fp);

    return;
}

void creat_command(FILE * fat32_fp, char * newFile) {
    uint32_t tempOffset = bpb_info.currentOffset;
    uint32_t tempClusNumber = bpb_info.currentClusNumber;
    uint32_t nextClusNumber = 0;
    uint32_t lastClusNumber = 0;

    // while loop for cluster chain (starting at current cluster)
    while (tempClusNumber >= bpb_info.minClusNumber && tempClusNumber <= bpb_info.maxClusNumber)
    {

        // finds the FAT entry of current cluster to find next cluster if there is one
        uint32_t fatOffset = clusNumToFatOffset(tempClusNumber);
        fseek(fat32_fp, fatOffset, SEEK_SET);
        fread(&nextClusNumber, sizeof(uint32_t), 1, fat32_fp);

        // reads all bytes at current cluser (512 bytes)
        for (int i = 0; i < 16; i++) {
            dentry_t *dentry = read_dir_entry(fat32_fp, tempOffset);
            tempOffset += 32;

            char * dirName = dentry->DIR_Name;
            remove_spaces(dirName);

            if (strcmp(newFile, dirName) == 0) {
                printf("A directory/file with the name '%s' already exists.\n", newFile);
                free(dentry);

                return;
            } else if (dentry->DIR_Name[0] == 0x00 || dentry->DIR_Name[0] == 0xE5) {
                // if empty entry is found, then create new file
                dentry_t newDentry;
                uint32_t newFileClusNumber = allocate_cluster(fat32_fp);

                strcpy(newDentry.DIR_Name, newFile);
                newDentry.DIR_Attr = 0x20;
                newDentry.DIR_FstClusHI = (newFileClusNumber >> 16) & 0xFFFF;
                newDentry.DIR_FstClusLO = newFileClusNumber & 0xFFFF;
                newDentry.DIR_FileSize = 0;

                fseek(fat32_fp, tempOffset - 32, SEEK_SET);
                fwrite(&newDentry, sizeof(dentry_t), 1, fat32_fp);

                free(dentry);

                return;
            }

            free(dentry);
        }

        // keeps track of last cluster in case cluster limit is reached
        lastClusNumber = tempClusNumber;

        // updates temp cluster number to find next set of data in cluster chain
        tempClusNumber = nextClusNumber;

        // updates temporary offset so data can be printed from new offset
        tempOffset = bpb_info.dataRegionAddress + (tempClusNumber - bpb_info.BPB_RootClus) * bpb_info.BPB_BytsPerSec;
    }

    // if cluster chain has no space, allocate space for a new cluster in chain and then add new directories
    uint32_t extendedDirClusNumber = extend_cluster_chain(fat32_fp, lastClusNumber);
    uint32_t newOffset = bpb_info.dataRegionAddress + (extendedDirClusNumber - bpb_info.BPB_RootClus) * bpb_info.BPB_BytsPerSec;
    dentry_t newDentry;
    uint32_t newFileClusNumber = allocate_cluster(fat32_fp);

    strcpy(newDentry.DIR_Name, newFile);
    newDentry.DIR_Attr = 0x20;
    newDentry.DIR_FstClusHI = (newFileClusNumber >> 16) & 0xFFFF;
    newDentry.DIR_FstClusLO = newFileClusNumber & 0xFFFF;
    newDentry.DIR_FileSize = 0;

    fseek(fat32_fp, newOffset, SEEK_SET);
    fwrite(&newDentry, sizeof(dentry_t), 1, fat32_fp);

    return;
}

int write_command(FILE * fat32_fp, OpenFile openFile, tokenlist * tokenList) {
    char * writeString = malloc(sizeof(char));

    for (int i = 0; i < strlen(tokenList->items[2]); i++) {
        tokenList->items[2][i] = tokenList->items[2][i + 1];
    }

    tokenList->items[tokenList->size - 1][strlen(tokenList->items[tokenList->size - 1]) - 1] = '\0';

    // creates new string that will be written to file based on tokens
    for (int i = 2; i < tokenList->size; i++) {
        writeString = realloc(writeString, strlen(writeString) + strlen(tokenList->items[i]) + 2);
        strcat(writeString, tokenList->items[i]);
        strcat(writeString, " ");
    }

    // removes last trailing space
    writeString[strlen(writeString) - 1] = '\0';

    uint32_t tempOffset = openFile.offsetInDataRegion + openFile.offsetInFile;
    uint32_t tempClusNumber = openFile.fileClusNumber;
    uint32_t nextClusNumber = 0;
    int bytesLeftToWrite = strlen(writeString);
    int currentByte = 0;
    int firstClusFlag = 1;
    int newClustersNeeded = 0;
    int newFileSize = openFile.offsetInFile + strlen(writeString);
    int newStrLength = strlen(writeString);

    // checks if last cluster has characters already (allocate more space if this value is negative)
    int charsInLastCluster = (newFileSize % 512) - strlen(writeString);

    // calculates amount of new clusters needed
    if (newFileSize > openFile.fileSize && charsInLastCluster < 0) {
        newClustersNeeded = (newFileSize - openFile.fileSize) / 512 + 1;
    }

    // finds last cluster if chain needs to be extended
    uint32_t extendedClusNumber = find_end_of_cluster_chain(fat32_fp, tempClusNumber);

    // adds necessary amount of clusters based on space needed for new file size
    for (int i = 0; i < newClustersNeeded; i++) {
        extendedClusNumber = extend_cluster_chain(fat32_fp, extendedClusNumber);
    }

    // while loop for cluster chain (starting at current cluster)
    while (tempClusNumber >= bpb_info.minClusNumber && tempClusNumber <= bpb_info.maxClusNumber)
    {
        // reads all bytes at current cluser (512 bytes)
        if (firstClusFlag == 1 && ((openFile.offsetInFile % 512) + bytesLeftToWrite) > 512) {
            char buffer[512 - (openFile.offsetInFile % 512)];
            buffer[512 - (openFile.offsetInFile % 512)] = '\0';

            for (int i = 0; i < (512 - (openFile.offsetInFile % 512)); i++) {
                buffer[i] = writeString[currentByte];
                currentByte++;
            }

            fseek(fat32_fp, tempOffset, SEEK_SET);
            fwrite(buffer, 512 - (openFile.offsetInFile % 512), 1, fat32_fp);

            bytesLeftToWrite -= 512 - (openFile.offsetInFile % 512);

            firstClusFlag = 0;
        } else {
            if (bytesLeftToWrite > 512) {
                char buffer[512];
                buffer[512] = '\0';

                for (int i = 0; i < 512; i++) {
                    buffer[i] = writeString[currentByte];
                    currentByte++;
                }

                fseek(fat32_fp, tempOffset, SEEK_SET);
                fwrite(buffer, 512, 1, fat32_fp);

                bytesLeftToWrite -= 512;
            } else {
                char buffer[bytesLeftToWrite];
                buffer[bytesLeftToWrite] = '\0';

                for (int i = 0; i < bytesLeftToWrite; i++) {
                    buffer[i] = writeString[currentByte];
                    currentByte++;
                }

                fseek(fat32_fp, tempOffset, SEEK_SET);
                fwrite(buffer, bytesLeftToWrite, 1, fat32_fp);

                bytesLeftToWrite = 0;
            }
        }

        // finds the FAT entry of current cluster to find next cluster if there is one
        uint32_t fatOffset = clusNumToFatOffset(tempClusNumber);
        fseek(fat32_fp, fatOffset, SEEK_SET);
        fread(&nextClusNumber, sizeof(uint32_t), 1, fat32_fp);

        // updates temp cluster number to find next set of data in cluster chain
        tempClusNumber = nextClusNumber;

        // updates temporary offset so data can be printed from new offset
        tempOffset = bpb_info.dataRegionAddress + (tempClusNumber - bpb_info.BPB_RootClus) * bpb_info.BPB_BytsPerSec;
    }

    free(writeString);

    return newStrLength;
}

int find_file(FILE * fat32_fp, char * targetFile) {
    uint32_t tempOffset = bpb_info.currentOffset;
    uint32_t tempClusNumber = bpb_info.currentClusNumber;
    uint32_t nextClusNumber = 0;

    // while loop for cluster chain (starting at current cluster)
    while (tempClusNumber >= bpb_info.minClusNumber && tempClusNumber <= bpb_info.maxClusNumber)
    {
        // finds the FAT entry of current cluster to find next cluster if there is one
        uint32_t fatOffset = clusNumToFatOffset(tempClusNumber);
        fseek(fat32_fp, fatOffset, SEEK_SET);
        fread(&nextClusNumber, sizeof(uint32_t), 1, fat32_fp);

        // for loop that iterates through all directory entries within cluster (32 * 16 bytes = 512)
        for (int i = 0; i < 16; i++) {
            dentry_t *dentry = read_dir_entry(fat32_fp, tempOffset);
            tempOffset += 32; // increments to next directory entry

            char dirName[strlen(dentry->DIR_Name)];
            strcpy(dirName, dentry->DIR_Name);
            remove_spaces(dirName);

            if (strcmp(targetFile, dirName) == 0) {
                free(dentry);
                return 1;
            }

            free(dentry);
        }

        // updates temp cluster number to find next set of data in cluster chain
        tempClusNumber = nextClusNumber;

        // updates temporary offset so data can be printed from new offset
        tempOffset = bpb_info.dataRegionAddress + (tempClusNumber - bpb_info.BPB_RootClus) * bpb_info.BPB_BytsPerSec;
    }

    return 0;
}

void lsof_command() {
    printf("%-12s%-12s%-12s%-12s%-12s\n", "INDEX", "NAME", "MODE", "OFFSET", "PATH");

    for (int i = 0; i < bpb_info.numOfOpenFiles; i++) {
        printf("%-12d", i);
        printf("%-12s", bpb_info.openedFiles[i].fileName);
        printf("%-12s", bpb_info.openedFiles[i].fileMode);
        printf("%-12u", bpb_info.openedFiles[i].offsetInFile);
        printf("%s\n", bpb_info.openedFiles[i].filePath);
    }
}


int is_directory_empty(FILE * fat32_fp, uint32_t firstClusNumber) {
    uint32_t tempClusNumber = firstClusNumber;
    uint32_t nextClusNumber = 0;

    while (tempClusNumber >= bpb_info.minClusNumber && tempClusNumber <= bpb_info.maxClusNumber)
    {
        uint32_t fatOffset = clusNumToFatOffset(tempClusNumber);
        fseek(fat32_fp, fatOffset, SEEK_SET);
        fread(&nextClusNumber, sizeof(uint32_t), 1, fat32_fp);

        uint32_t tempOffset = bpb_info.dataRegionAddress + (tempClusNumber - bpb_info.BPB_RootClus) * bpb_info.BPB_BytsPerSec;
        for (int i = 0; i < 16; i++) {
            dentry_t * subDentry = read_dir_entry(fat32_fp, tempOffset + i * 32);
            char * subDirName = subDentry->DIR_Name;
            remove_spaces(subDirName);
            if (subDirName[0] != '\0' && strcmp(subDirName, ".") != 0 && strcmp(subDirName, "..") != 0) {
                free(subDentry);
                return 0; // Directory is not empty
            }
            free(subDentry);
        }

        tempClusNumber = nextClusNumber;
    }

    return 1; // Directory is empty
}

void reset_cluster_chain(FILE * fat32_fp, uint32_t firstClusNumber) {
    uint32_t tempClusNumber = firstClusNumber;
    uint32_t nextClusNumber = 0;

    while (tempClusNumber >= bpb_info.minClusNumber && tempClusNumber <= bpb_info.maxClusNumber)
    {
        uint32_t fatOffset = clusNumToFatOffset(tempClusNumber);
        fseek(fat32_fp, fatOffset, SEEK_SET);
        fread(&nextClusNumber, sizeof(uint32_t), 1, fat32_fp);

        // Write 0 to the FAT entry
        fseek(fat32_fp, fatOffset, SEEK_SET);
        uint32_t zero = 0;
        fwrite(&zero, sizeof(uint32_t), 1, fat32_fp);

        // Write 0 to the data cluster
        uint32_t tempOffset = bpb_info.dataRegionAddress + (tempClusNumber - bpb_info.BPB_RootClus) * bpb_info.BPB_BytsPerSec;
        char buffer[bpb_info.BPB_BytsPerSec];
        memset(buffer, 0, sizeof(buffer));
        fseek(fat32_fp, tempOffset, SEEK_SET);
        fwrite(&buffer, sizeof(buffer), 1, fat32_fp);

        tempClusNumber = nextClusNumber;
    }
}


void rm_command(FILE * fat32_fp, char * delDir, int dirOrFile) {
    uint32_t tempOffset = bpb_info.currentOffset;
    uint32_t tempClusNumber = bpb_info.currentClusNumber;
    uint32_t nextClusNumber = 0;

    while (tempClusNumber >= bpb_info.minClusNumber && tempClusNumber <= bpb_info.maxClusNumber)
    {
        uint32_t fatOffset = clusNumToFatOffset(tempClusNumber);
        fseek(fat32_fp, fatOffset, SEEK_SET);
        fread(&nextClusNumber, sizeof(uint32_t), 1, fat32_fp);

        for (int i = 0; i < 16; i++) {
            dentry_t * dentry = read_dir_entry(fat32_fp, tempOffset);
            tempOffset += 32;

            uint32_t dirClusNumber = (dentry->DIR_FstClusHI << 16) | dentry->DIR_FstClusLO;

            if (dentry->DIR_Attr != 0x10 && dirOrFile == 1) {
                char * dirName = dentry->DIR_Name;
                remove_spaces(dirName);

                if (strcmp(delDir, dirName) == 0) {
                        printf("Error: %s is not a directory\n", delDir);
                        free(dentry);
                        return;
                }
            } else if (dentry->DIR_Attr == 0x10 && dirOrFile == 2) {
                char * dirName = dentry->DIR_Name;
                remove_spaces(dirName);

                if (strcmp(delDir, dirName) == 0) {
                        printf("Error: %s is a directory\n", delDir);
                        free(dentry);
                        return;
                }
            } else if (dentry->DIR_Attr == 0x10 && dirOrFile == 1) {
                char * dirName = dentry->DIR_Name;
                remove_spaces(dirName);

                if (strcmp(delDir, dirName) == 0) {
                    if (is_directory_empty(fat32_fp, dirClusNumber) == 0) {
                        printf("Error: %s is not an empty directory\n", delDir);
                        free(dentry);
                        return;
                    } else {
                        // Reset the FAT cluster chain and the data cluster
                        reset_cluster_chain(fat32_fp, dirClusNumber);

                        char buffer[32];
                        for (int i = 0; i < 32; i++)
                            buffer[i] = '\0';
                        fseek(fat32_fp, tempOffset - 32, SEEK_SET);
                        fwrite(&buffer, sizeof(buffer), 1, fat32_fp);
                        free(dentry);
                        return;
                    }
                }
            } else if (dentry->DIR_Attr != 0x10 && dirOrFile == 2) {
                char * dirName = dentry->DIR_Name;
                remove_spaces(dirName);

                if (strcmp(delDir, dirName) == 0) {
                    // Reset the FAT cluster chain and the data cluster
                    reset_cluster_chain(fat32_fp, dirClusNumber);

                    char buffer[32];
                    for (int i = 0; i < 32; i++)
                        buffer[i] = '\0';
                    fseek(fat32_fp, tempOffset - 32, SEEK_SET);
                    fwrite(&buffer, sizeof(buffer), 1, fat32_fp);
                    free(dentry);
                    return;
                }
            }

            free(dentry);
        }

        tempClusNumber = nextClusNumber;
        tempOffset = bpb_info.dataRegionAddress + (tempClusNumber - bpb_info.BPB_RootClus) * bpb_info.BPB_BytsPerSec;
    }

    printf("Error: File not found in current directory\n");
    return;
}



int main(int argc, char const *argv[])
{
    if (argc != 2) {
        printf("Invalid number of arguments.\n");
        return -1;
    }

    char * imgFileName;
    char * imgPathName;

    imgFileName = malloc(strlen(argv[1]) + 1);
    strcpy(imgFileName, argv[1]);

    imgPathName = malloc(strlen(imgFileName) + 2);
    strcpy(imgPathName, imgFileName);
    strcat(imgPathName, "/");

    FILE * fp = fopen(imgFileName, "r+b");

    if (fp == NULL) {
        printf("File does not exist.\n");
        return -1;
    }

    fseek(fp, 11, SEEK_SET);
    fread(&bpb_info.BPB_BytsPerSec, sizeof(bpb_info.BPB_BytsPerSec), 1, fp);

    fseek(fp, 13, SEEK_SET);
    fread(&bpb_info.BPB_SecPerClus, sizeof(bpb_info.BPB_SecPerClus), 1, fp);

    fseek(fp, 14, SEEK_SET);
    fread(&bpb_info.BPB_RsvdSecCnt, sizeof(bpb_info.BPB_RsvdSecCnt), 1, fp);

    fseek(fp, 16, SEEK_SET);
    fread(&bpb_info.BPB_NumFATs, sizeof(bpb_info.BPB_NumFATs), 1, fp);

    fseek(fp, 36, SEEK_SET);
    fread(&bpb_info.BPB_FATSz32, sizeof(bpb_info.BPB_FATSz32), 1, fp);

    fseek(fp, 44, SEEK_SET);
    fread(&bpb_info.BPB_RootClus, sizeof(bpb_info.BPB_RootClus), 1, fp);

    fseek(fp, 0, SEEK_END);
    bpb_info.imgSize = ftell(fp);

    bpb_info.dataRegionAddress = bpb_info.BPB_BytsPerSec * (bpb_info.BPB_RsvdSecCnt + bpb_info.BPB_FATSz32 * bpb_info.BPB_NumFATs);
    bpb_info.numOfClusInRegion = (bpb_info.imgSize - bpb_info.dataRegionAddress) / bpb_info.BPB_BytsPerSec;
    bpb_info.numOfEntriesPerFAT = (bpb_info.BPB_FATSz32 * bpb_info.BPB_BytsPerSec) / 4;
    bpb_info.currentOffset = bpb_info.dataRegionAddress;
    bpb_info.currentClusNumber = bpb_info.BPB_RootClus;
    bpb_info.maxClusNumber = bpb_info.BPB_FATSz32 / bpb_info.BPB_SecPerClus;
    bpb_info.minClusNumber = bpb_info.BPB_RootClus;
    bpb_info.numOfOpenFiles = 0;

    while (1)
    {
        // Display the command prompt
        printf("%s> ", imgPathName);

        // Get user input and tokenize it
        char *input = get_input();
        tokenlist *tokens = get_tokens(input);

        // If there are tokens, process them
        if (tokens->size > 0)
        {
            if (strcmp(tokens->items[0], "exit") == 0)
            {
                free(input);
                free_tokens(tokens);
                free(imgFileName);
                free(imgPathName);
                fclose(fp);

                exit(0);
            } else if (strcmp(tokens->items[0], "info") == 0)
            {
                print_info();
            } else if (strcmp(tokens->items[0], "ls") == 0)
            {
                ls_command(fp);
            } else if (strcmp(tokens->items[0], "cd") == 0)
            {
                int cdFlag = cd_command(fp, tokens->items[1]);

                if (cdFlag == 1) {
                    if (strcmp(tokens->items[1], "..") == 0)
                    {
                        imgPathName[strlen(imgPathName) - 1] = '\0';

                        while (imgPathName[strlen(imgPathName) - 1] != '/') {
                            imgPathName[strlen(imgPathName) - 1] = '\0';
                        }
                    } else if (strcmp(tokens->items[1], ".") != 0) {
                        imgPathName = realloc(imgPathName, strlen(imgPathName) + strlen(tokens->items[1]) + 2);
                        strcat(imgPathName, tokens->items[1]);
                        strcat(imgPathName, "/");
                    }
                } else if (cdFlag == -1) {
                    printf("Target directory not found (or file is not a directory).\n");
                }
            } else if (strcmp(tokens->items[0], "open") == 0 && tokens->size == 3)
            {
                if (strcmp(tokens->items[2], "-r") == 0 || strcmp(tokens->items[2], "-w") == 0
                    || strcmp(tokens->items[2], "-rw") == 0 || strcmp(tokens->items[2], "-wr") == 0) {
                    int openFlag = open_command(fp, tokens->items[1], tokens->items[2]);

                    if (openFlag == 1) {
                        bpb_info.openedFiles[bpb_info.numOfOpenFiles].fileName = malloc(strlen(tokens->items[1]));
                        strcpy(bpb_info.openedFiles[bpb_info.numOfOpenFiles].fileName, tokens->items[1]);
                        bpb_info.openedFiles[bpb_info.numOfOpenFiles].filePath = malloc(strlen(imgPathName));
                        strcpy(bpb_info.openedFiles[bpb_info.numOfOpenFiles].filePath, imgPathName);
                        bpb_info.numOfOpenFiles++;
                    } else if (openFlag == 0) {
                        printf("File was not found in current working directory.\n");
                    }
                } else {
                    printf("Invalid file mode flag.\n");
                }
            } else if (strcmp(tokens->items[0], "close") == 0)
            {
                int closeFlag = 0;
                int fileOpenIndex = check_file_open(tokens->items[1]);

                if (fileOpenIndex != -1) {
                    closeFlag = close_command(fp, tokens->items[1], fileOpenIndex);
                }

                if (closeFlag == 0) {
                    printf("Invalid file name or file is not currently open.\n");
                } else if (closeFlag == -1) {
                    printf("File was not found in current working directory.\n");
                }
            } else if (strcmp(tokens->items[0], "lseek") == 0 && tokens->size == 3)
            {
                int lseekFlag = 0;
                int fileOpenIndex = check_file_open(tokens->items[1]);

                if (fileOpenIndex != -1) {
                    lseekFlag = lseek_command(fp, tokens->items[1], atoi(tokens->items[2]), fileOpenIndex);
                }

                if (lseekFlag == 0) {
                    printf("Invalid file name or file is not currently open.\n");
                } else if (lseekFlag == -1) {
                    printf("File was not found in current working directory.\n");
                } else if (lseekFlag == -2) {
                    printf("Offset that was entered exceeds file size.\n");
                }
            } else if (strcmp(tokens->items[0], "write") == 0 && tokens->size >= 3)
            {
                int fileInDirectory = find_file(fp, tokens->items[1]);
                int fileOpenIndex = check_file_open(tokens->items[1]);

                if (fileInDirectory == 0) {
                    printf("File was not found in current working directory.\n");
                } else if (fileOpenIndex == -1) {
                    printf("Invalid file name or file is not currently open.\n");
                } else if (strcmp(bpb_info.openedFiles[fileOpenIndex].fileMode, "r") == 0) {
                    printf("Selected file is not in write mode.\n");
                } else if (tokens->items[2][0] == 34 && tokens->items[tokens->size - 1][strlen(tokens->items[tokens->size - 1]) - 1] == 34) {
                    int newStringLength = write_command(fp, bpb_info.openedFiles[fileOpenIndex], tokens);
                    uint32_t newFileSize = bpb_info.openedFiles[fileOpenIndex].offsetInFile + newStringLength;
                    bpb_info.openedFiles[fileOpenIndex].offsetInFile += newStringLength;

                    if (newFileSize > bpb_info.openedFiles[fileOpenIndex].fileSize) {
                        // updates file size data in both openFile data stucture and within image file
                        fseek(fp, bpb_info.openedFiles[fileOpenIndex].offsetInParent + 28, SEEK_SET);
                        fwrite(&newFileSize, sizeof(uint32_t), 1, fp);
                        bpb_info.openedFiles[fileOpenIndex].fileSize = newFileSize;
                    }
                } else {
                    printf("String to be written must be enclosed in quotes.\n");
                }
            } else if (strcmp(tokens->items[0], "read") == 0 && tokens->size == 3)
            {
                int fileInDirectory = find_file(fp, tokens->items[1]);
                int fileOpenIndex = check_file_open(tokens->items[1]);

                if (fileInDirectory == 0) {
                    printf("File was not found in current working directory.\n");
                } else if (fileOpenIndex == -1) {
                    printf("Invalid file name or file is not currently open.\n");
                } else if (strcmp(bpb_info.openedFiles[fileOpenIndex].fileMode, "w") == 0) {
                    printf("Selected file is not in read mode.\n");
                } else {
                    bpb_info.openedFiles[fileOpenIndex].offsetInFile += read_command(fp, bpb_info.openedFiles[fileOpenIndex], atoi(tokens->items[2]));
                }
            } else if (strcmp(tokens->items[0], "mkdir") == 0 && tokens->size == 2)
            {
                mkdir_command(fp, tokens->items[1]);
            } else if (strcmp(tokens->items[0], "creat") == 0 && tokens->size == 2)
            {
                creat_command(fp, tokens->items[1]);
            } else if (strcmp(tokens->items[0], "lsof") == 0)
            {
                lsof_command();
            } else if (strcmp(tokens->items[0], "rm") == 0 && tokens->size == 2)
            {
                int fileOpenIndex = check_file_open(tokens->items[1]);

                if (fileOpenIndex != -1) {
                    printf("File is currently open and cannot be deleted.\n");
                } else {
                    rm_command(fp, tokens->items[1], 2);
                }
            } else if (strcmp(tokens->items[0], "rmdir") == 0 && tokens->size == 2)
            {
                int fileOpenIndex = check_file_open(tokens->items[1]);

                if (fileOpenIndex != -1) {
                    printf("File is currently open and cannot be deleted.\n");
                } else {
                    rm_command(fp, tokens->items[1], 1);
                }
            }
        }

        // Free the input and token list
        free(input);
        free_tokens(tokens);
    }

    free(imgFileName);
    free(imgPathName);

    fclose(fp);

    return 0;
}
