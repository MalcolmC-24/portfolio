# Project 3: FAT32 File System

For this project our team developed a program which successfully mounts a FAT32 image file and provies functionality similar to a shell that will allow a user to navigate the data stored within the image file. The available commands that a user can utilize are CRUD based commands which allow the users to seamlessly navigat the file system while being able to make appropriate changes to create and delete files and directories. The FAT32 image file is read using various systems to access different offsets within the image file to find information such as boot specifications, cluster information from the FAT region, and data stored at different locations in the data region. Conversions are used to find clusters from the FAT table and access different information across various cluster chains to successfully traverse and edit the mounted image file.

## Group Members
- **Malcolm Carroll**: mtc20d@fsu.edu
- **Aaron Garman**: aag15b@fsu.edu
- **Damian Gonzalez**: dag21g@fsu.edu

## Division of Labor

### Part 1: Mount the Image File (mount, info, exit)
- **Responsibilities**: Implemented logic to open FAT32 image file and mount it. Also created info and exit commands to display boot information from image file and exit program safely.
- **Assigned to**: Aaron, Malcolm

### Part 2: Navigation (cd, ls)
- **Responsibilities**: Created cd and ls commands to enable navigation across different directories in file system and list files in current directory.
- **Assigned to**: Damian, Malcolm

### Part 3: Create (mkdir, creat)
- **Responsibilities**: Created mkdir and creat commands to enable brand new files and directories to be generated in file system.
- **Assigned to**: Malcolm, Damian

### Part 4: Read (open, close, lsof, lseek, read)
- **Responsibilities**: Creates open, close, lsof, lseek and read commands to keep track of open files and set offset for reading and writing.
- **Assigned to**: Damian, Aaron

### Part 5: Update (write)
- **Responsibilities**: Created write command to enable files to have strings written to them at a given offset.
- **Assigned to**: Aaron, Damian

### Part 6: Delete (rm, rmdir)
- **Responsibilities**: Created rm and rmdir commands to enable files and empty directories to be deleted from file system.
- **Assigned to**: Malcolm, Aaron

## File Listing
```
root/
├──   src/
|     └─── filesys.c
└───  Makefile
└───  README.md
```

## How to Compile & Execute

### Requirements
- **Compiler**: `gcc` (CFLAGS: -g -Wall -std=c99)
- **Dependencies**: N/A - developed in C

### Compilation
To compile the source code run the following command from root which will build an executable called filesys in "bin":

```bash
make
```

### Execution
Once filesys execuatable file is placed in "bin", navigate to "bin" and using a valid FAT32 image file run the following command:

```bash
./filesys [FAT32 ISO]
```

## Bugs
- No apparent bugs were found during testing. All provided test cases work as intended.

## Considerations
- No extra credit problems were solved. However, all required parts are completed.

