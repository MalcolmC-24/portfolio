#include <unistd.h>

int main() {
	sleep(0);
	sleep(0);
	sleep(0);
	sleep(0);
	sleep(0);
}
