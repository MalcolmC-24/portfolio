
#include <linux/init.h>
#include <linux/module.h>
#include <linux/proc_fs.h>
#include <linux/uaccess.h>
#include <linux/timekeeping.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("cop4610-group8");
MODULE_DESCRIPTION("Kernel module for timer");

#define ENTRY_NAME "timer"
#define PERMS 0644
#define PARENT NULL

static struct timespec64 ts_old;

static struct proc_dir_entry* timer_entry;

long long int calcTimeDiff(struct timespec64 newTime, struct timespec64 oldTime) {
    if (oldTime.tv_sec == 0) {
        return newTime.tv_sec - newTime.tv_sec;
    }
    else {
        return newTime.tv_sec - oldTime.tv_sec;
    }
}

long int calcTimeDiffNano(struct timespec64 newTime, struct timespec64 oldTime) {
    if (oldTime.tv_sec == 0) {
        return newTime.tv_nsec - newTime.tv_nsec;
    }
    else {
        return newTime.tv_nsec - oldTime.tv_nsec;
    }
}

static ssize_t timer_read(struct file *file, char __user *ubuf, size_t count, loff_t *ppos)
{
    struct timespec64 ts_now;
    long long int elapsedTime;
    long int elapsedTimeNano;
    char buf[256];
    int len = 0;

    ktime_get_real_ts64(&ts_now);

    elapsedTime = calcTimeDiff(ts_now, ts_old);
    elapsedTimeNano = calcTimeDiffNano(ts_now, ts_old);

    if (ts_old.tv_nsec > ts_now.tv_nsec) {
        elapsedTime--;
        elapsedTimeNano *= -1;
    }

    len = sprintf(buf + len, "current time: %lld.%ld\n", (long long)ts_now.tv_sec,
		  (long int)ts_now.tv_nsec);

    if (elapsedTime > 0) {
        len += sprintf(buf + len, "elapsed time: %lld.%ld\n", (long long)elapsedTime, 
		       (long int)elapsedTimeNano);
    }

    ts_old.tv_sec = ts_now.tv_sec;
    ts_old.tv_nsec = ts_now.tv_nsec;

    return simple_read_from_buffer(ubuf, count, ppos, buf, len);
}

static const struct proc_ops timer_fops = {
    .proc_read = timer_read,
};

static int __init timer_init(void)
{
    timer_entry = proc_create(ENTRY_NAME, PERMS, PARENT, &timer_fops);
    if (!timer_entry) {
        return -ENOMEM;
    }

    ts_old.tv_sec = 0;
    ts_old.tv_nsec = 0;

    return 0;
}

static void __exit timer_exit(void)
{
    proc_remove(timer_entry);
}

module_init(timer_init);
module_exit(timer_exit);
