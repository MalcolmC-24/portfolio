#include <linux/init.h>
#include <linux/module.h>
#include <linux/proc_fs.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <linux/uaccess.h>
#include <linux/kernel.h>
#include <linux/kthread.h>
#include <linux/mutex.h>
#include <linux/delay.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("cop4610-group8");
MODULE_DESCRIPTION("Kernel module for elevator implementation");

#define ENTRY_NAME "elevator"
#define ENTRY_SIZE 1000
#define PERMS 0644
#define PARENT NULL

struct {
    char state[10];
    int floor;
    int weight;
    int numPassengers;
    int isStopping;
    struct list_head passengerList;
} elevatorCar;

typedef struct person {
    int type;
    char typeStr[4];
    int weight;
    int destFloor;
    struct list_head list;
} Person;

struct {
    int peopleWaiting;
    int passengersServiced;
    char floorStatus[6];
    struct list_head * floors[5];
} building;

static struct proc_dir_entry* elevator_entry;

static DEFINE_MUTEX(elevatorCar_lock);
static struct task_struct *elevator_kthread;

int elevator_move(void * data);

extern int (*STUB_start_elevator)(void);
extern int (*STUB_issue_request)(int,int,int);
extern int (*STUB_stop_elevator)(void);

// add logic to these 3 functions
int start_elevator(void) {
    if (strcmp(elevatorCar.state, "OFFLINE") != 0) {
        return 1;
    }

    elevator_kthread = kthread_run(elevator_move, NULL, "elevator_kthread");
    if (IS_ERR(elevator_kthread)) {
        printk(KERN_ERR "Failed to create kthread\n");
	return -ENOMEM;
    }

    return 0;
}

int issue_request(int start_floor, int destination_floor, int type) {
    if (elevatorCar.isStopping == 1) {
        return 1;
    }

    Person * newPassenger = kmalloc(sizeof(Person), __GFP_RECLAIM);
    newPassenger->destFloor = destination_floor;
    newPassenger->type = type;

    switch(type) {
        case 0:
            snprintf(newPassenger->typeStr, 4, "P%d ", destination_floor);
            newPassenger->weight = 2; // weights multiplied by 2 for floats
            break;
        case 1:
            snprintf(newPassenger->typeStr, 4, "L%d ", destination_floor);
            newPassenger->weight = 3;
            break;
        case 2:
            snprintf(newPassenger->typeStr, 4, "B%d ", destination_floor);
            newPassenger->weight = 4;
            break;
        case 3:
            snprintf(newPassenger->typeStr, 4, "V%d ", destination_floor);
            newPassenger->weight = 1;
            break;
    }

    // adds passenger to list based on start_floor
    mutex_lock(&elevatorCar_lock);
    list_add_tail(&newPassenger->list, building.floors[start_floor - 1]);
    mutex_unlock(&elevatorCar_lock);

    building.peopleWaiting++;

    return 0;
}

int stop_elevator(void) {
    if (elevatorCar.isStopping == 1) {
        return 1;
    }

    elevatorCar.isStopping = 1;

    return 0;
}

void addPassengers(void) {
    if (elevatorCar.numPassengers >= 5) {
        return;
    }

    Person * movingPassenger;
    struct list_head * temp;
    struct list_head * dummy;

    list_for_each_safe(temp, dummy, building.floors[elevatorCar.floor - 1]) {
        movingPassenger = list_entry(temp, Person, list);

        if ((movingPassenger->weight + elevatorCar.weight) <= 14
	    && elevatorCar.numPassengers < 5) {
            strcpy(elevatorCar.state, "LOADING");

            list_del(&movingPassenger->list);
            list_add_tail(&movingPassenger->list, &elevatorCar.passengerList);

            building.peopleWaiting--;
            elevatorCar.numPassengers++;
            elevatorCar.weight += movingPassenger->weight;
        }
    }
    msleep(1000);
}

void removePassengers(void) {
    if (elevatorCar.numPassengers == 0) {
        return;
    }

    Person * movingPassenger;
    struct list_head * temp;
    struct list_head * dummy;

    list_for_each_safe(temp, dummy, &elevatorCar.passengerList) {
        movingPassenger = list_entry(temp, Person, list);

        if (movingPassenger->destFloor == elevatorCar.floor) {
            strcpy(elevatorCar.state, "LOADING");

            list_del(&movingPassenger->list);
            kfree(movingPassenger);

            elevatorCar.weight -= movingPassenger->weight;
            elevatorCar.numPassengers--;
            building.passengersServiced++;
        }
    }
    msleep(1000);
}

char * printElevList(void) {
    struct list_head * temp;
    Person * currentPassenger;
    char * passengerString;

    list_for_each(temp, &elevatorCar.passengerList) {
        currentPassenger = list_entry(temp, Person, list);

        if (passengerString == NULL) {
            passengerString = kmalloc(strlen(currentPassenger->typeStr) + 1, __GFP_RECLAIM);
            strcpy(passengerString, currentPassenger->typeStr);
        } else {
            passengerString = krealloc(passengerString,
			               strlen(passengerString)
				       + strlen(currentPassenger->typeStr) + 1,
				       __GFP_RECLAIM);
            strcat(passengerString, currentPassenger->typeStr);
        }
    }

    if (passengerString == NULL) {
        passengerString = krealloc(passengerString, sizeof(char) * 1, __GFP_RECLAIM);
    }

    return passengerString;
}

char * printFloorList(int floor) {
    struct list_head * temp;
    Person * currentPassenger;
    char * passengerString;

    list_for_each(temp, building.floors[floor - 1]) {
        currentPassenger = list_entry(temp, Person, list);

        if (passengerString == NULL) {
            passengerString = kmalloc(strlen(currentPassenger->typeStr) + 1, __GFP_RECLAIM);
            strcpy(passengerString, currentPassenger->typeStr);
        } else {
            passengerString = krealloc(passengerString,
				       strlen(passengerString)
				       + strlen(currentPassenger->typeStr) + 1,
				       __GFP_RECLAIM);
            strcat(passengerString, currentPassenger->typeStr);
        }
    }

    if (passengerString == NULL) {
        passengerString = krealloc(passengerString, sizeof(char) * 1, __GFP_RECLAIM);
    }

    return passengerString;
}

int passengersOnFloor(int floor) {
    int passengers = 0;
    struct list_head * temp;

    list_for_each(temp, building.floors[floor - 1]) {
        passengers++;
    }

    return passengers;
}

int elevator_move(void * data) {
    int elevator_direction = 1; // 1 for up, -1 for down

    while (!kthread_should_stop()) {
        if (elevator_direction == 1) {
            // Move up
            if (elevatorCar.floor < 5) {
                building.floorStatus[elevatorCar.floor - 1] = ' ';
                elevatorCar.floor++;
		strcpy(elevatorCar.state, "UP");
                building.floorStatus[elevatorCar.floor - 1] = '*';
		msleep(2000);
            } else {
                elevator_direction = -1; // Change direction to down
            }
        } else if (elevator_direction == -1) {
            // Move down
            if (elevatorCar.floor > 1) {
                building.floorStatus[elevatorCar.floor - 1] = ' ';
                elevatorCar.floor--;
		strcpy(elevatorCar.state, "DOWN");
                building.floorStatus[elevatorCar.floor - 1] = '*';
		msleep(2000);
            } else {
                elevator_direction = 1; // Change direction to up
            }
        }
        mutex_lock(&elevatorCar_lock); // Acquire the mutex
        removePassengers();
        addPassengers();
        mutex_unlock(&elevatorCar_lock); // Release the mutex
	if (building.peopleWaiting == 0 && elevatorCar.numPassengers == 0
	    && elevatorCar.isStopping == 0) {
		elevator_direction = 0;
		strcpy(elevatorCar.state, "IDLE");
	} else if (building.peopleWaiting == 0 && elevatorCar.numPassengers == 0
		   && elevatorCar.isStopping == 1) {
                elevatorCar.isStopping = 0;
                strcpy(elevatorCar.state, "OFFLINE");
                kthread_stop(elevator_kthread);
        } else if (elevatorCar.floor != 5 && elevator_direction != -1) {
                elevator_direction = 1;
        } else if (elevatorCar.floor != 1 && elevator_direction != 1) {
                elevator_direction = -1;
        }
    }

    return 0;
}

static ssize_t elevator_read(struct file *file, char __user *ubuf, size_t count, loff_t *ppos)
{
    char buf[10000];
    int len = 0;

    char * floorOneString = printFloorList(1);
    char * floorTwoString = printFloorList(2);
    char * floorThreeString = printFloorList(3);
    char * floorFourString = printFloorList(4);
    char * floorFiveString = printFloorList(5);
    char * elevatorString = printElevList();

    int floorOneCount = passengersOnFloor(1);
    int floorTwoCount = passengersOnFloor(2);
    int floorThreeCount = passengersOnFloor(3);
    int floorFourCount = passengersOnFloor(4);
    int floorFiveCount = passengersOnFloor(5);

    int realWeight = elevatorCar.weight / 2;

    len = sprintf(buf, "Elevator state: %s\n", elevatorCar.state);
    len += sprintf(buf + len, "Current floor: %d\n", elevatorCar.floor);

    if (elevatorCar.weight % 2 == 0) {
        len += sprintf(buf + len, "Current load: %d\n", realWeight);
    } else {
        len += sprintf(buf + len, "Current load: %d.5\n", realWeight);
    }

    len += sprintf(buf + len, "Elevator status: %s\n\n", elevatorString);

    len += sprintf(buf + len, "[%c] Floor 5: %d %s\n", building.floorStatus[4],
		   floorFiveCount, floorFiveString);
    len += sprintf(buf + len, "[%c] Floor 4: %d %s\n", building.floorStatus[3],
		   floorFourCount, floorFourString);
    len += sprintf(buf + len, "[%c] Floor 3: %d %s\n", building.floorStatus[2],
		   floorThreeCount, floorThreeString);
    len += sprintf(buf + len, "[%c] Floor 2: %d %s\n", building.floorStatus[1],
		   floorTwoCount, floorTwoString);
    len += sprintf(buf + len, "[%c] Floor 1: %d %s\n\n", building.floorStatus[0],
		   floorOneCount, floorOneString);

    len += sprintf(buf + len, "Number of passengers: %d\n", elevatorCar.numPassengers);
    len += sprintf(buf + len, "Number of passengers waiting: %d\n", building.peopleWaiting);
    len += sprintf(buf + len, "Number of passengers serviced: %d\n\n",
		   building.passengersServiced);

    kfree(floorOneString);
    kfree(floorTwoString);
    kfree(floorThreeString);
    kfree(floorFourString);
    kfree(floorFiveString);
    kfree(elevatorString);

    return simple_read_from_buffer(ubuf, count, ppos, buf, len);
}

static const struct proc_ops elevator_fops = {
    .proc_read = elevator_read,
};

static int __init elevator_init(void)
{
    elevator_entry = proc_create(ENTRY_NAME, PERMS, PARENT, &elevator_fops);

    if (!elevator_entry) {
        return -ENOMEM;
    }

    STUB_start_elevator = start_elevator;
    STUB_issue_request = issue_request;
    STUB_stop_elevator = stop_elevator;

    for (int i = 0; i < 5; i++) {
        building.floors[i] = kmalloc(sizeof(struct list_head), __GFP_RECLAIM);
        INIT_LIST_HEAD(building.floors[i]);
    }

    strcpy(elevatorCar.state, "OFFLINE");
    elevatorCar.floor = 1;
    elevatorCar.weight = 0;
    elevatorCar.numPassengers = 0;
    elevatorCar.isStopping = 0;
    building.floorStatus[0] = '*';
    building.floorStatus[1] = ' ';
    building.floorStatus[2] = ' ';
    building.floorStatus[3] = ' ';
    building.floorStatus[4] = ' ';
    building.floorStatus[5] = '\0';
    building.passengersServiced = 0;
    INIT_LIST_HEAD(&elevatorCar.passengerList);

    return 0;
}

static void __exit elevator_exit(void)
{
    proc_remove(elevator_entry);

    STUB_start_elevator = NULL;
    STUB_issue_request = NULL;
    STUB_stop_elevator = NULL;

    for (int i = 0; i < 5; i++) {
        if (building.floors[i]) {
            kfree(building.floors[i]);
        }
    }
}

module_init(elevator_init);
module_exit(elevator_exit);
