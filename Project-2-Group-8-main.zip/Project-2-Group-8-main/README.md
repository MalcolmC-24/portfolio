# Project 2: Elevator Kernel Module

Our team completed a comprehensive project focusing on system calls, kernel programming, concurrency, synchronization, and elevator scheduling algorithms. The project was divided into three parts, each building upon previous knowledge. In Part 1, we explored system calls, integrating them into a C program to interact with the kernel and rigorously testing their correctness using the "strace" tool. Part 2 involved delving deeper into kernel programming, where we developed a kernel module named "my_timer" and established a proc entry for communication, gaining insights into kernel modules and proc interfaces. Finally, in Part 3, we implemented an elevator scheduling algorithm for a dormitory elevator, designing a kernel module for the elevator, providing a "/proc/elevator" entry for critical information display, and addressing challenges in concurrency and synchronization to ensure efficient scheduling and safety within the kernel environment.

## Group Members
- **Malcolm Carroll**: mtc20d@fsu.edu
- **Aaron Garman**: aag15b@fsu.edu
- **Damian Gonzalez**: dag21g@fsu.edu

## Division of Labor

### Part 1: System Call Tracing
- **Responsibilities**: Used strace to trace the 5 system calls to generate debugging information on them.
- **Assigned to**: Malcolm, Aaron, Damian

### Part 2: Timer Kernel Module
- **Responsibilities**: Created kernel module that writes the current and the elapsed time since the last call to the proc file.
- **Assigned to**: Malcolm, Aaron

### Part 3a: Adding System Calls
- **Responsibilities**: Downloaded the latest linux kernel release and added the 3 new system calls to it.
- **Assigned to**: Aaron, Damian

### Part 3b: Kernel Compilation
- **Responsibilities**: Edited all necessary files in the kernel and successfully compiled it.
- **Assigned to**: Aaron, Damian

### Part 3c: Threads
- **Responsibilities**: Used a kthread to control the elevator movement.
- **Assigned to**: Malcolm

### Part 3d: Linked List
- **Responsibilities**: Used linked lists to handle the number of people on each floor and the elevator.
- **Assigned to**: Aaron, Damian

### Part 3e: Mutexes
- **Responsibilities**: Used a mutex to control shared data access between the floors and the elevator.
- **Assigned to**: Malcolm

### Part 3f: Scheduling Algorithm
- **Responsibilities**: Implemented algorithm to move the elevator up and down to access each floor.
- **Assigned to**: Malcolm, Damian

## File Listing
```
root/
├──   part1/
|     ├──  empty.c
|     ├──  empty.trace
|     ├──  part1.c
|     ├──  part1.trace
|     └─── Makefile
|
├──   part2/
|     ├──  src/
|     |    └─── timer.c
|     └─── Makefile
|
├──   part3/
|     ├──  src/
|     |    └─── elevator.c
|     ├──  syscalls.c
|     └─── Makefile
|
└───  README.md
```

## How to Compile & Execute

### Requirements
- **Virtual Machine**: Ubuntu 23.0
- **Test Documents**: producer.c and consumer.c (provided by instructors)
- **Compiler**: `gcc` (CFLAGS: -g -Wall -std=c99)
- **Dependencies**: N/A - developed in C

### Compilation
To compile each part of the project call the following commands from their directories:

```bash
make
```

Then do the following for part 2:
```bash
cd src
sudo insmod timer.ko
```

Or for part 3:
```bash
cd src
sudo insmod elevator.ko
```

### Execution
To run the project, execute the following commands from provided test files after kernel module is inserted:

For part 2 (as many times as necessary):
```bash
cat /proc/timer
```

For part 3:
```bash
./producer [int]
./consumer --start
watch -n [snds] cat /proc/elevator
```

## Bugs
- No apparent bugs were found during testing. All provided test cases work as intended.

## Considerations
- No extra credit problems were solved. However, all required parts are completed.

